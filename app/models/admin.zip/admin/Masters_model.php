<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Masters_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }
	public function updateSetting($data)
    {
        $this->db->where('setting_id', '1');
        if ($this->db->update('settings', $data)) {
            return true;
        }
        return false;
    }
	
	/*### User Department*/
	function add_user_department($data){
		$this->db->insert('user_department', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_user_department($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('user_department',$data)){
	    	return true;
		}
		return false;
    }
    function getUser_departmentby_ID($id){
		$this->db->select('*');
		$this->db->from('user_department');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLUser_department(){
		$q = $this->db->get('user_department');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_user_department_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('user_department',$data)){
			return true;
		}
		return false;
    }
	
	/*### Taxi Category*/
	function add_taxi_category($data){
		$this->db->insert('taxi_categorys', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_taxi_category($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('taxi_categorys',$data)){
	    	return true;
		}
		return false;
    }
    function getTaxi_categoryby_ID($id){
		$this->db->select('*');
		$this->db->from('taxi_categorys');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLTaxi_category(){
		$q = $this->db->get('taxi_categorys');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_taxi_category_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('taxi_categorys',$data)){
			return true;
		}
		return false;
    }
	
	/*### Taxi Fuel*/
	function add_taxi_fuel($data){
		$this->db->insert('taxi_fuel', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_taxi_fuel($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('taxi_fuel',$data)){
	    	return true;
		}
		return false;
    }
    function getTaxi_fuelby_ID($id){
		$this->db->select('*');
		$this->db->from('taxi_fuel');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLTaxi_fuel(){
		$q = $this->db->get('taxi_fuel');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_taxi_fuel_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('taxi_fuel',$data)){
			return true;
		}
		return false;
    }
	/*### Taxi Type*/
	function add_taxi_type($data){
		$this->db->insert('taxi_type', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_taxi_type($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('taxi_type',$data)){
	    	return true;
		}
		return false;
    }
    function getTaxi_typeby_ID($id){
		$this->db->select('*');
		$this->db->from('taxi_type');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLTaxi_type(){
		$q = $this->db->get('taxi_type');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
	function checkTaxi_type($name, $category_id){
		$q = $this->db->get_where('taxi_type',array('category_id'=>$category_id, 'name' => $name));
       	if($q->num_rows()>0){
			return TRUE;
		}
		return FALSE;
	}
    function update_taxi_type_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('taxi_type',$data)){
			return true;
		}
		return false;
    }
	/*### Currency*/
    function add_currency($data){
		$this->db->insert('currencies', $data);
        return $this->db->insert_id();	
    }
    function update_currency($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('currencies',$data)){
	    	return true;
		}
		return false;
    }
    function getCurrencyby_ID($id){
		$this->db->select('*');
		$this->db->from('currencies');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLCurrency(){
		$q = $this->db->get('currencies');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
		}
		return false;
	}
    function update_currency_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('currencies',$data)){
			return true;
		}
		return false;
    }
	/*### Continent*/
	function add_continent($data){
		$this->db->insert('continents', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_continent($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('continents',$data)){
	    	return true;
		}
		return false;
    }
    function getContinentby_ID($id){
		$this->db->select('*');
		$this->db->from('continents');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLContinents(){
		$q = $this->db->get('continents');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_continent_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('continents',$data)){
			return true;
		}
		return false;
    }
	
	/*### Country*/
	function add_country($data){
		$this->db->insert('countries', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_country($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('countries',$data)){
	    	return true;
		}
		return false;
    }
    function getCountryby_ID($id){
		$this->db->select('*');
		$this->db->from('countries');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLCountry(){
		$q = $this->db->get('countries');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_country_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('countries',$data)){
			return true;
		}
		return false;
    }
	
	/*### Zone*/
	function add_zone($data){
		$this->db->insert('zones', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_zone($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('zones',$data)){
	    	return true;
		}
		return false;
    }
    function getZoneby_ID($id){
		$this->db->select('*');
		$this->db->from('zones');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLZone(){
		$q = $this->db->get('zones');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_zone_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('zones',$data)){
			return true;
		}
		return false;
    }
   
   /*### State*/
	function add_state($data){
		$this->db->insert('states', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_state($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('states',$data)){
	    	return true;
		}
		return false;
    }
    function getStateby_ID($id){
		$this->db->select('*');
		$this->db->from('states');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLState(){
		$q = $this->db->get('states');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_state_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('states',$data)){
			return true;
		}
		return false;
    }
	
	/*### City*/
	function add_city($data){
		$this->db->insert('cities', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_city($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('cities',$data)){
	    	return true;
		}
		return false;
    }
    function getCityby_ID($id){
		$this->db->select('*');
		$this->db->from('cities');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLCity(){
		$q = $this->db->get('cities');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_city_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('cities',$data)){
			return true;
		}
		return false;
    }
	
	/*### Area*/
	function add_area($data){
		$this->db->insert('areas', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_area($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('areas',$data)){
	    	return true;
		}
		return false;
    }
    function getAreaby_ID($id){
		$this->db->select('*');
		$this->db->from('areas');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLArea(){
		$q = $this->db->get('areas');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_area_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('areas',$data)){
			return true;
		}
		return false;
    }
	
	/*#### Check Continent country zone state city*/
	
	function checkCountry($name, $continent_id){
		$q = $this->db->get_where('countries',array('continent_id'=>$continent_id, 'name' => $name));
       	if($q->num_rows()>0){
			return TRUE;
		}
		return FALSE;
	}
	
	function checkZone($name, $country_id){
		$q = $this->db->get_where('zones',array('country_id'=>$country_id, 'name' => $name));
       	if($q->num_rows()>0){
			return TRUE;
		}
		return FALSE;
	}
	
	function checkState($name, $zone_id){
		$q = $this->db->get_where('states',array('zone_id'=>$zone_id, 'name' => $name));
       	if($q->num_rows()>0){
			return TRUE;
		}
		return FALSE;
	}
	
	function checkCity($name, $state_id){
		$q = $this->db->get_where('cities',array('state_id'=>$state_id, 'name' => $name));
       	if($q->num_rows()>0){
			return TRUE;
		}
		return FALSE;
	}
	
	/*#### Json Country Zone State city area*/
	
	function getCountry_bycontinent($continent_id){
		$q = $this->db->get_where('countries',array('continent_id'=>$continent_id));
       	if($q->num_rows()>0){
			return $q->result();
		}
		return false;
    }
	
	function getZone_bycountry($country_id){
		$q = $this->db->get_where('zones',array('country_id'=>$country_id));
       	if($q->num_rows()>0){
			return $q->result();
		}
		return false;
    }
	
	function getState_byzone($zone_id){
		$q = $this->db->get_where('states',array('zone_id'=>$zone_id));
       	if($q->num_rows()>0){
			return $q->result();
		}
		return false;
    }
	
	function getCity_bystate($state_id){
		$q = $this->db->get_where('cities',array('state_id'=>$state_id));
       	if($q->num_rows()>0){
			return $q->result();
		}
		return false;
    }
	
	function getArea_bycity($city_id){
		$q = $this->db->get_where('areas',array('city_id'=>$city_id));
       	if($q->num_rows()>0){
			return $q->result();
		}
		return false;
    }
	
	/*#### User Group*/
    function add_user_group($data){
		$this->db->insert('groups', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
    function getUserGroupby_ID($id){
		$this->db->select('*');
		$this->db->from('groups');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
    function update_user_group($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('groups',$data)){
			return true;
		}
		return false;
    }
    
}
