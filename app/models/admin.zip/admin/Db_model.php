<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Db_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }
	
	public function getUrlData($group_id){
		if(!empty($group_id)){
			$data = array();
			
			if($group_id == 1 || $group_id == 2){
				$q = $this->db->select('*')->get('users');
				 if ($q->num_rows() > 0) {
					
					foreach(($q->result())  as $row){
						
						if($row->active == 1){
							if($row->group_id == 3){
								$vendor_active[] = $row;
							}elseif($row->group_id == 4){
								$driver_active[] = $row;
							}elseif($row->group_id == 5){
								$customer_active[] = $row;
							}elseif($row->group_id == 6){
								$employee_active[] = $row;
							}
						}else{
							if($row->group_id == 3){
								$vendor_inactive[] = $row;
							}elseif($row->group_id == 4){
								$driver_inactive[] = $row;
							}elseif($row->group_id == 5){
								$customer_inactive[] = $row;
							}elseif($row->group_id == 6){
								$employee_inactive[] = $row;
							}
						}
					}
				}
				
				$r = $this->db->select('*')->get('rides');
				 if ($r->num_rows() > 0) {
					
					foreach(($r->result())  as $ride){
						
						if($ride->booked_type == 1){
							$cityride[] = $ride;
						}elseif($ride->booked_type == 2){
							$rental[] = $ride;
						}elseif($ride->booked_type == 3){
							$outstation[] = $ride;
						}
						
						if($ride->status == 1){
							$request[] = $ride;
						}elseif($ride->status == 2){
							$booked[] = $ride;
						}elseif($ride->status == 3){
							$onride[] = $ride;
						}elseif($ride->status == 4){
							$waiting[] = $ride;
						}elseif($ride->status == 5){
							$completed[] = $ride;
						}elseif($ride->status == 6){
							$cancelled[] = $ride;
						}elseif($ride->status == 7){
							$ride_later[] = $ride;
						}
					}
					
				}
				
				$t = $this->db->select('*')->get('taxi_type');
				 if ($t->num_rows() > 0) {
					
					foreach(($t->result())  as $ttype){
						$taxi[$ttype->id]  = $this->db->select('*')->where('type', $ttype->id)->get('taxi');
						if ($taxi[$ttype->id]->num_rows() > 0) {
							foreach(($taxi[$ttype->id]->result()) as $taxi_val){
								$taxi[$ttype->name][] = $taxi_val;
							}
						}
						
						$data['taxi'][] = array('title' => $ttype->name, 'total' => count($taxi[$ttype->name]));
					}
					
					
					
				 }
				 
				$data['user'][] = array('title' => 'Vendor', 'active' => count($vendor_active), 'inactive' => count($vendor_inactive), 'color' => 'bg-aqua',  'link' => admin_url('people/vendor'),  'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Driver', 'active' => count($driver_active), 'inactive' => count($driver_inactive), 'color' => 'bg-green', 'link' => admin_url('people/driver'), 'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Customer', 'active' => count($customer_active), 'inactive' => count($customer_inactive), 'color' => 'bg-yellow', 'link' => admin_url('people/customer'),  'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Employee', 'active' => count($employee_active), 'inactive' => count($employee_inactive), 'color' => 'bg-maroon', 'link' => admin_url('people/employee'), 'icon' => 'fa-bar-chart');
				
				$data['ride'][] = array('category' => 'Request Ride', 'value' => count($request), 'full' => '100');
				$data['ride'][] = array('category' => 'Booked Ride', 'value' => count($booked), 'full' => '100');
				$data['ride'][] = array('category' => 'Onride', 'value' => count($onride), 'full' => '100');
				$data['ride'][] = array('category' => 'Waiting Ride', 'value' => count($waiting), 'full' => '100');
				$data['ride'][] = array('category' => 'Completed Ride', 'value' => count($completed), 'full' => '100');
				$data['ride'][] = array('category' => 'Cancelled Ride', 'value' => count($cancelled), 'full' => '100');
				$data['ride'][] = array('category' => 'Ride Later', 'value' => count($ride_later), 'full' => '100');
				
				$data['booked_ride'][] = array('title' => 'City Ride', 'total' => count($cityride), 'color' => 'progress-bar-danger');
				$data['booked_ride'][] = array('title' => 'Rental Ride', 'total' => count($rental), 'color' => 'progress-bar-success');
				$data['booked_ride'][] = array('title' => 'Outstation', 'total' => count($outstation), 'color' => 'progress-bar-warning');
				
				
				
			}elseif($group_id == 3){
				$q = $this->db->select('*')->get('users');
				 if ($q->num_rows() > 0) {
					
					foreach(($q->result())  as $row){
						
						if($row->active == 1){
							if($row->group_id == 3){
								$vendor_active[] = $row;
							}elseif($row->group_id == 4 && $row->parent_id == $this->session->userdata('user_id')){
								$driver_active[] = $row;
							}elseif($row->group_id == 5){
								$customer_active[] = $row;
							}elseif($row->group_id == 6){
								$employee_active[] = $row;
							}
						}else{
							if($row->group_id == 3){
								$vendor_inactive[] = $row;
							}elseif($row->group_id == 4 && $row->parent_id == $this->session->userdata('user_id')){
								$driver_inactive[] = $row;
							}elseif($row->group_id == 5){
								$customer_inactive[] = $row;
							}elseif($row->group_id == 6){
								$employee_inactive[] = $row;
							}
						}
					}
				}
				
				$r = $this->db->select('*')->where('vendor_id', $this->session->userdata('user_id'))->get('rides');
				 if ($r->num_rows() > 0) {
					
					foreach(($r->result())  as $ride){
						
						if($ride->booked_type == 1){
							$cityride[] = $ride;
						}elseif($ride->booked_type == 2){
							$rental[] = $ride;
						}elseif($ride->booked_type == 3){
							$outstation[] = $ride;
						}
						
						if($ride->status == 1){
							$request[] = $ride;
						}elseif($ride->status == 2){
							$booked[] = $ride;
						}elseif($ride->status == 3){
							$onride[] = $ride;
						}elseif($ride->status == 4){
							$waiting[] = $ride;
						}elseif($ride->status == 5){
							$completed[] = $ride;
						}elseif($ride->status == 6){
							$cancelled[] = $ride;
						}elseif($ride->status == 7){
							$ride_later[] = $ride;
						}
					}
					
				}
				
				$t = $this->db->select('*')->get('taxi_type');
				 if ($t->num_rows() > 0) {
					
					foreach(($t->result())  as $ttype){
						$taxi[$ttype->id]  = $this->db->select('*')->where('type', $ttype->id)->where('user_id', $this->session->userdata('user_id'))->get('taxi');
						if ($taxi[$ttype->id]->num_rows() > 0) {
							foreach(($taxi[$ttype->id]->result()) as $taxi_val){
								if($taxi_val->is_verify == 1){
									$vendortaxi_active[] = $taxi_val;
								}else{
									$vendortaxi_inactive[] = $taxi_val;
								}
								$taxi[$ttype->name][] = $taxi_val;
							}
						}
						
						$data['taxi'][] = array('title' => $ttype->name, 'total' => count($taxi[$ttype->name]));
					}
					
					
					
				 }
				 
				$data['user'][] = array('title' => 'Driver', 'active' => count($driver_active), 'inactive' => count($driver_inactive), 'color' => 'bg-green', 'link' => admin_url('people/driver'), 'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Customer', 'active' => count($customer_active), 'inactive' => count($customer_inactive), 'color' => 'bg-yellow', 'link' => admin_url('people/customer'),  'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Taxi', 'active' => count($vendortaxi_active), 'inactive' => count($vendortaxi_inactive), 'color' => 'bg-maroon',  'link' => admin_url('taxi'),  'icon' => 'fa-bar-chart');
				
				$data['ride'][] = array('category' => 'Request Ride', 'value' => count($request), 'full' => '100');
				$data['ride'][] = array('category' => 'Booked Ride', 'value' => count($booked), 'full' => '100');
				$data['ride'][] = array('category' => 'Onride', 'value' => count($onride), 'full' => '100');
				$data['ride'][] = array('category' => 'Waiting Ride', 'value' => count($waiting), 'full' => '100');
				$data['ride'][] = array('category' => 'Completed Ride', 'value' => count($completed), 'full' => '100');
				$data['ride'][] = array('category' => 'Cancelled Ride', 'value' => count($cancelled), 'full' => '100');
				$data['ride'][] = array('category' => 'Ride Later', 'value' => count($ride_later), 'full' => '100');
				
				$data['booked_ride'][] = array('title' => 'City Ride', 'total' => count($cityride), 'color' => 'progress-bar-danger');

				$data['booked_ride'][] = array('title' => 'Rental Ride', 'total' => count($rental), 'color' => 'progress-bar-success');
				$data['booked_ride'][] = array('title' => 'Outstation', 'total' => count($outstation), 'color' => 'progress-bar-warning');
			}elseif($group_id == 4){
				$q = $this->db->select('*')->get('users');
				 if ($q->num_rows() > 0) {
					
					foreach(($q->result())  as $row){
						
						if($row->active == 1){
							if($row->group_id == 3){
								$vendor_active[] = $row;
							}elseif($row->group_id == 4 && $row->parent_id == $this->session->userdata('user_id')){
								$driver_active[] = $row;
							}elseif($row->group_id == 5){
								$customer_active[] = $row;
							}elseif($row->group_id == 6){
								$employee_active[] = $row;
							}
						}else{
							if($row->group_id == 3){
								$vendor_inactive[] = $row;
							}elseif($row->group_id == 4 && $row->parent_id == $this->session->userdata('user_id')){
								$driver_inactive[] = $row;
							}elseif($row->group_id == 5){
								$customer_inactive[] = $row;
							}elseif($row->group_id == 6){
								$employee_inactive[] = $row;
							}
						}
					}
				}
				
				$r = $this->db->select('*')->where('driver_id', $this->session->userdata('user_id'))->get('rides');
				 if ($r->num_rows() > 0) {
					
					foreach(($r->result())  as $ride){
						
						if($ride->booked_type == 1){
							$cityride[] = $ride;
						}elseif($ride->booked_type == 2){
							$rental[] = $ride;
						}elseif($ride->booked_type == 3){
							$outstation[] = $ride;
						}
						
						if($ride->status == 1){
							$request[] = $ride;
						}elseif($ride->status == 2){
							$booked[] = $ride;
						}elseif($ride->status == 3){
							$onride[] = $ride;
						}elseif($ride->status == 4){
							$waiting[] = $ride;
						}elseif($ride->status == 5){
							$completed[] = $ride;
						}elseif($ride->status == 6){
							$cancelled[] = $ride;
						}elseif($ride->status == 7){
							$ride_later[] = $ride;
						}
					}
					
				}
				
				$t = $this->db->select('*')->get('taxi_type');
				 if ($t->num_rows() > 0) {
					
					foreach(($t->result())  as $ttype){
						$taxi[$ttype->id]  = $this->db->select('*')->where('type', $ttype->id)->where('user_id', $this->session->userdata('user_id'))->get('taxi');
						if ($taxi[$ttype->id]->num_rows() > 0) {
							foreach(($taxi[$ttype->id]->result()) as $taxi_val){
								if($taxi_val->is_verify == 1){
									$vendortaxi_active[] = $taxi_val;
								}else{
									$vendortaxi_inactive[] = $taxi_val;
								}
								$taxi[$ttype->name][] = $taxi_val;
							}
						}
						
						$data['taxi'][] = array('title' => $ttype->name, 'total' => count($taxi[$ttype->name]));
					}
					
					
					
				 }
				 
				
				
				$data['ride'][] = array('category' => 'Request Ride', 'value' => count($request), 'full' => '100');
				$data['ride'][] = array('category' => 'Booked Ride', 'value' => count($booked), 'full' => '100');
				$data['ride'][] = array('category' => 'Onride', 'value' => count($onride), 'full' => '100');
				$data['ride'][] = array('category' => 'Waiting Ride', 'value' => count($waiting), 'full' => '100');
				$data['ride'][] = array('category' => 'Completed Ride', 'value' => count($completed), 'full' => '100');
				$data['ride'][] = array('category' => 'Cancelled Ride', 'value' => count($cancelled), 'full' => '100');
				$data['ride'][] = array('category' => 'Ride Later', 'value' => count($ride_later), 'full' => '100');
				
				$data['booked_ride'][] = array('title' => 'City Ride', 'total' => count($cityride), 'color' => 'progress-bar-danger');
				$data['booked_ride'][] = array('title' => 'Rental Ride', 'total' => count($rental), 'color' => 'progress-bar-success');
				$data['booked_ride'][] = array('title' => 'Outstation', 'total' => count($outstation), 'color' => 'progress-bar-warning');
			}elseif($group_id == 6){
				$q = $this->db->select('*')->get('users');
				 if ($q->num_rows() > 0) {
					
					foreach(($q->result())  as $row){
						
						if($row->active == 1){
							if($row->group_id == 3){
								$vendor_active[] = $row;
							}elseif($row->group_id == 4){
								$driver_active[] = $row;
							}elseif($row->group_id == 5){
								$customer_active[] = $row;
							}elseif($row->group_id == 6){
								$employee_active[] = $row;
							}
						}else{
							if($row->group_id == 3){
								$vendor_inactive[] = $row;
							}elseif($row->group_id == 4){
								$driver_inactive[] = $row;
							}elseif($row->group_id == 5){
								$customer_inactive[] = $row;
							}elseif($row->group_id == 6){
								$employee_inactive[] = $row;
							}
						}
					}
				}
				
				$r = $this->db->select('*')->get('rides');
				 if ($r->num_rows() > 0) {
					
					foreach(($r->result())  as $ride){
						
						if($ride->booked_type == 1){
							$cityride[] = $ride;
						}elseif($ride->booked_type == 2){
							$rental[] = $ride;
						}elseif($ride->booked_type == 3){
							$outstation[] = $ride;
						}
						
						if($ride->status == 1){
							$request[] = $ride;
						}elseif($ride->status == 2){
							$booked[] = $ride;
						}elseif($ride->status == 3){
							$onride[] = $ride;
						}elseif($ride->status == 4){
							$waiting[] = $ride;
						}elseif($ride->status == 5){
							$completed[] = $ride;
						}elseif($ride->status == 6){
							$cancelled[] = $ride;
						}elseif($ride->status == 7){
							$ride_later[] = $ride;
						}
					}
					
				}
				
				$t = $this->db->select('*')->get('taxi_type');
				 if ($t->num_rows() > 0) {
					
					foreach(($t->result())  as $ttype){
						$taxi[$ttype->id]  = $this->db->select('*')->where('type', $ttype->id)->where('user_id', $this->session->userdata('user_id'))->get('taxi');
						if ($taxi[$ttype->id]->num_rows() > 0) {
							foreach(($taxi[$ttype->id]->result()) as $taxi_val){
								if($taxi_val->is_verify == 1){
									$vendortaxi_active[] = $taxi_val;
								}else{
									$vendortaxi_inactive[] = $taxi_val;
								}
								$taxi[$ttype->name][] = $taxi_val;
							}
						}
						
						$data['taxi'][] = array('title' => $ttype->name, 'total' => count($taxi[$ttype->name]));
					}
					
					
					
				 }
				 
				$data['user'][] = array('title' => 'Vendor', 'active' => count($vendor_active), 'inactive' => count($vendor_inactive), 'color' => 'bg-aqua',  'link' => admin_url('people/vendor'),  'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Driver', 'active' => count($driver_active), 'inactive' => count($driver_inactive), 'color' => 'bg-green', 'link' => admin_url('people/driver'), 'icon' => 'fa-bar-chart');
				$data['user'][] = array('title' => 'Customer', 'active' => count($customer_active), 'inactive' => count($customer_inactive), 'color' => 'bg-yellow', 'link' => admin_url('people/customer'),  'icon' => 'fa-bar-chart');
				
				
				$data['booked_ride'][] = array('title' => 'City Ride', 'total' => count($cityride), 'color' => 'progress-bar-danger');
				$data['booked_ride'][] = array('title' => 'Rental Ride', 'total' => count($rental), 'color' => 'progress-bar-success');
				$data['booked_ride'][] = array('title' => 'Outstation', 'total' => count($outstation), 'color' => 'progress-bar-warning');
			}
			
			return $data;
		}
		return false;
	}
    public function getLatestSales()
    {
        
    }

    public function getLastestQuotes()
    {
      
    }

    public function getLatestPurchases()
    {
        
    }

    public function getLatestTransfers()
    {
      
    }

    public function getLatestCustomers()
    {
    }

    public function getLatestSuppliers()
    {
       
    }

    public function getChartData()
    {
       
    }

    public function getStockValue()
    {
       
    }

    public function getBestSeller($start_date = NULL, $end_date = NULL)
    {
        
    }

}
