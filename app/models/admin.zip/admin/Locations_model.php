<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Locations_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }
   
   	/*### Daily*/
	function add_daily($data){
		$this->db->insert('daily_fare', $data);//print_r($this->db->last_query());die;
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_daily($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('daily_fare',$data)){
	    	return true;
		}
		return false;
    }
    function getDailyby_ID($id){
		$this->db->select('*');
		$this->db->from('daily_fare');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLDaily(){
		$q = $this->db->get('daily_fare');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_daily_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('daily_fare',$data)){
			return true;
		}
		return false;
    }
	
	/*### Rental*/
	function add_rental($data){
		$this->db->insert('rental_fare', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_rental($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('rental_fare',$data)){
	    	return true;
		}
		return false;
    }
    function getRentalby_ID($id){
		$this->db->select('*');
		$this->db->from('rental_fare');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLRental(){
		$q = $this->db->get('rental_fare');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_rental_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('rental_fare',$data)){
			return true;
		}
		return false;
    }
	
	/*### Outstation*/
	function add_outstation($data){
		$this->db->insert('outstation_fare', $data);
        if($id = $this->db->insert_id()){
	    	return true;
		}
		return false;
    }
	function update_outstation($id,$data){
		$this->db->where('id',$id);
		if($this->db->update('outstation_fare',$data)){
	    	return true;
		}
		return false;
    }
    function getOutstationby_ID($id){
		$this->db->select('*');
		$this->db->from('outstation_fare');
		$this->db->where('id',$id);
		$q = $this->db->get();
		if($q->num_rows()>0){
			return $q->row();
		}
		return false;
    }
	function getALLOutstation(){
		$q = $this->db->get('outstation_fare');
		if($q->num_rows()>0){
			foreach (($q->result()) as $row) {
                $data[] = $row;
            }
			return $data;
		}
		return false;
	}
    function update_outstation_status($data,$id){
		$this->db->where('id',$id);
		if($this->db->update('outstation_fare',$data)){
			return true;
		}
		return false;
    }
	
}
